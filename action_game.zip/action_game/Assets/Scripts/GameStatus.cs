﻿using System.Collections;
using UnityEngine;

public static class GameStatus {
    public static string gameStatus = "";
}
